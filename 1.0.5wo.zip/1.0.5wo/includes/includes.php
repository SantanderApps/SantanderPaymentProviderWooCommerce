<?php

/**
 * @file includes.php
 * @author Consid S5 AB <henrik.soderlind@consid.se>
 * @version 1.0.0
 * @created 2015-aug-24
 */

require_once _santander_get_plugin_path() . 'ext/santander/src/autoloader.php';
require_once __DIR__ . '/classes/Santander_APIConnector.php';