<?php
/*
Plugin Name: Santander Consumer Bank - WooCommerce Payment Gateway
Plugin URI: https://github.com/SantanderApps/SantanderPaymentProviderWooCommerce
Description: Integrates Santander Consumer Bank into WooCommerce.
Version: 1.0.5wo
Author: Santander
Author URI: http://santander.consid.se
*/

/**
 * This function will run when the plugin is activated in the admin area,
 * @global integer $user_ID
 */
function santander_activate() {
	global $user_ID;
	
	$page = array(
		'post_type' => 'page',
		'post_content' => '',
		'post_parent' => 0,
		'post_author' => $user_ID,
		'post_status' => 'publish',
		'post_title' => 'Santander Log',
	);
	$page = apply_filters( 'santander_add_new_page', $page, 'teams' );
	$page_id = wp_insert_post( $page );
	if ( $page_id > 0 ) {
		add_option( 'santander_log_page', $page_id );
	}
    
	add_option( 'santander_installation_date', date( 'Y-m-d H:i' ) );
    
	include_once( 'gateways/santander-loan.php' );
	Santander::run( new Santander_APIConnector( new Santander_Loan() ) );
	$headers = 'From: ' . Santander::$api->config->getSiteName() . ' <' . Santander::$api->config->getSiteEmailAddress() . '>' . "\r\n";
	$link = get_permalink( get_option( 'santander_log_page' ) );
	$link .= ( strpos( $link, '?' ) === FALSE ? '?' : '&' ) . 'd={date}';
	$email_text = 'The log file is located at ' . $link;
	wp_mail( 'santander@consid.se', 'New installation', $email_text, $headers );
}

/**
 * This function will run when the plugin is deactivated in the admin area.
 */
function santander_deactivate() {
	$log_page_id = get_option( 'santander_log_page' );
    
	if ( $log_page_id ) {
		wp_delete_post( $log_page_id, TRUE );
		delete_option( 'santander_log_page' );
		unset( $log_page_id );
	}
	
	delete_option( 'santander_installation_date' );
}

/**
 * This function will run when the plugins are loaded.
 * @return null
 */
function santander_init() {
	// If the parent WC_Payment_Gateway class doesn't exist
	// it means WooCommerce is not installed on the site
	// so do nothing
	if ( ! class_exists( 'WC_Payment_Gateway' ) ) {
		return;
	}
	
	// If we made it this far, then include our Gateway Class
	include_once( 'gateways/santander-loan.php' );
	
	// Now that we have successfully included our class,
	// Lets add it too WooCommerce
	add_filter( 'woocommerce_payment_gateways', 'santander_add_gateway' );
}

/**
 * Tell WooCommerce about our gateway.
 * @param array $methods
 * @return array
 */
function santander_add_gateway( $methods ) {
	$methods[] = 'Santander_Loan';
	return $methods;
}

/**
 * Display configuration link in the plugin area
 * @param array $links
 * @return array
 */
function santander_action_links( $links ) {
	$plugin_links = array(
		'<a href="' . admin_url( 'admin.php?page=wc-settings&tab=checkout&section=santander_loan' ) . '">' . __( 'Settings', 'santander' ) . '</a>',
	);
	
	return array_merge( $plugin_links, $links );
}

/**
 * This function is hooked to the action pre_get_posts.
 * @param type $query
 */
function santander_pre_get_posts( $query ) {
	$checkout_page_id = get_option( 'woocommerce_checkout_page_id' );
	$santander_log_page_id = get_option( 'santander_log_page' );
	
	if ( $query->is_main_query() && ( ( isset( $query->query['page_id'] ) && $query->query['page_id'] == $checkout_page_id ) || ( isset( $query->queried_object) && $query->queried_object->ID == $checkout_page_id ) ) && isset( $_GET['token'] ) ) {
		$santanderLoan = new Santander_Loan();
		$santanderLoan->check_result( $_GET['token'] );
		exit;
	} elseif ( $query->is_main_query() && ( ( isset( $query->query['page_id'] ) && $query->query['page_id'] == $santander_log_page_id ) || ( isset( $query->queried_object) && $query->queried_object->ID == $santander_log_page_id ) ) ) {
		Santander::run( new Santander_APIConnector( new Santander_Loan() ) );
		print Santander::$logger->getLogFile( ( isset( $_GET['d'] ) ? (int) $_GET['d'] : time() ) );
		exit;
    }
}

/**
 * Return the URL to the plugin
 * @return string
 */
function _santander_get_plugin_url() {
	return plugin_dir_url( __FILE__ );
}

/**
 * Return the filesystem path to the plugin
 * @return string
 */
function _santander_get_plugin_path() {
	return plugin_dir_path( __FILE__ );
}

register_activation_hook( __FILE__, 'santander_activate' );
register_deactivation_hook( __FILE__, 'santander_deactivate' );

// Action hooks
add_action( 'plugins_loaded', 'santander_init' );
add_action( 'pre_get_posts', 'santander_pre_get_posts' );

// Filter hooks
add_filter( 'plugin_action_links_' . plugin_basename( __FILE__ ), 'santander_action_links' );