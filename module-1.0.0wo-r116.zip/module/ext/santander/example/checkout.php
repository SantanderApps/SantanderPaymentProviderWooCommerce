<?php
    session_start();
    error_reporting(E_ALL);
    
    define('WEB_ROOT', __DIR__);
    
    require __DIR__ . '/../src/autoloader.php';
    require __DIR__ . '/includes/includes.php';
    require __DIR__ . '/../src/Santander.php';
    Santander::run(new Connector()); // Kickstart the API
    
    $pingWsdlResult = Santander::$api->pingHost();
    $pingSfResult = Santander::$api->pingHost('sf');
    $usedApiMethods = array(
        array(
            'label' => 'Santander::$api->pingHost()',
            'result' => print_r($pingWsdlResult, TRUE),
        ),
        array(
            'label' => 'Santander::$api->pingHost(\'sf\')',
            'result' => print_r($pingSfResult, TRUE),
        ),
    );
    
    // Assuming we don't have a token in the URL, this is the first step
    if (!isset($_GET['Token']) || strlen($_GET['Token']) == 0) {
        /*
         * Check if the user has posted amount etc, if so we should call the web
         * service method GetToken  
         */
        if (isset($_POST['orderNumber']) && isset($_POST['amount'])) {
            // Add orderNumber to session as it is needed in getResult
            $_SESSION['__orderNumber'] = $_POST['orderNumber'];
            $token = Santander::$api->getToken($_POST['orderNumber'], $_POST['amount']);
            $usedApiMethods[] = array(
                'label' => 'Santander::$api->getToken($_POST[\'orderNumber\'], $_POST[\'amount\'])',
                'result' => print_r($token, TRUE),
            );
            // We got a token, so lets forward the user to the Easy Web Site
            if ($token->isOk) {
                header('Location: ' . Santander::$api->config->getRedirectUrl($token->token));
                exit;
            }
        }
    }
    else {
        $getResult = Santander::$api->getResult($_GET['Token'], $_SESSION['__orderNumber']);
        $usedApiMethods[] = array(
            'label' => 'Santander::$api->getResult($_GET[\'Token\'], $_SESSION[\'__orderNumber\'])',
            'result' => print_r($getResult, TRUE),
        );
    }
?>
<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <!-- The above 3 meta tags *must* come first in the head; any other head content must come *after* these tags -->
    <meta name="description" content="">
    <meta name="author" content="">

    <title>Santander Low Level API - Example</title>

    <!-- Bootstrap core CSS -->
    <link href="bootstrap/css/bootstrap.min.css" rel="stylesheet">
    
    <!-- Custom styles for this template -->
    <link href="http://getbootstrap.com/examples/starter-template/starter-template.css" rel="stylesheet">

    <!-- Just for debugging purposes. Don't actually copy these 2 lines! -->
    <!--[if lt IE 9]><script src="http://getbootstrap.com/assets/js/ie8-responsive-file-warning.js"></script><![endif]-->
    <script src="http://getbootstrap.com/assets/js/ie-emulation-modes-warning.js"></script>

    <!-- HTML5 shim and Respond.js for IE8 support of HTML5 elements and media queries -->
    <!--[if lt IE 9]>
      <script src="https://oss.maxcdn.com/html5shiv/3.7.2/html5shiv.min.js"></script>
      <script src="https://oss.maxcdn.com/respond/1.4.2/respond.min.js"></script>
    <![endif]-->
  </head>

  <body>

    <nav class="navbar navbar-inverse navbar-fixed-top">
      <div class="container">
        <div class="navbar-header">
          <button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#navbar" aria-expanded="false" aria-controls="navbar">
            <span class="sr-only">Toggle navigation</span>
            <span class="icon-bar"></span>
            <span class="icon-bar"></span>
            <span class="icon-bar"></span>
          </button>
          <a class="navbar-brand" href="/">Santander Low Level API - Example</a>
        </div>
        <div id="navbar" class="collapse navbar-collapse">
          <ul class="nav navbar-nav">
            <li class="active"><a href="/">Home</a></li>
          </ul>
        </div><!--/.nav-collapse -->
      </div>
    </nav>

    <div class="container">
        <div class="starter-template">
            <?php if ($pingWsdlResult['latency'] === FALSE): ?>
            <div class="alert alert-danger">Ping <?php print $pingWsdlResult['host']; ?> failed!</div>
            <?php else: ?>
            <div class="alert alert-success">Successfully pinged web service <?php print $pingWsdlResult['host']; ?>! Latency: <?php print $pingWsdlResult['latency']; ?></div>
            <?php endif; ?>

            <?php if ($pingSfResult['latency'] === FALSE): ?>
            <div class="alert alert-danger">Ping <?php print $pingSfResult['host']; ?> failed!</div>
            <?php else: ?>
            <div class="alert alert-success">Successfully pinged web site <?php print $pingSfResult['host']; ?>! Latency: <?php print $pingSfResult['latency']; ?></div>
            <?php endif; ?>
          
            <h1>Checkout</h1>
            
            <?php if ($getResult->isOk): ?>
            <div class="alert alert-success">
                <p>You have successfully completed an order using Santander Consumer Bank!</p>
                <p>
                    The order will be shiped to:<br>
                    <address>
                        <?php print $getResult->address->firstName . ' ' . $getResult->address->lastName; ?><br>
                        <?php print $getResult->address->address; ?><br>
                        <?php print $getResult->address->postCode . ' ' . $getResult->address->city; ?>
                    </address>
                </p>
                <p>Authorization Code: <?php print $getResult->authorizationCode; ?></p>
            </div>
            <?php else: ?>
            <div class="alert alert-danger">
                <p><?php print $getResult->humanFailureMessage; ?></p>
            </div>
            <?php endif; ?>
        </div>
        
        <form>
            <fieldset>
                <legend>Used API-methods</legend>
                <?php foreach($usedApiMethods as $method): ?>
                <div class="form-group">
                    <label><?php print $method['label']; ?></label>
                    <textarea readonly="" cols="60" rows="10" class="form-control"><?php print htmlspecialchars($method['result']); ?></textarea>
                </div>
                <?php endforeach; ?>
            </fieldset>
        </form>
    </div><!-- /.container -->


    <!-- Bootstrap core JavaScript
    ================================================== -->
    <!-- Placed at the end of the document so the pages load faster -->
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/1.11.3/jquery.min.js"></script>
    <script src="../../dist/js/bootstrap.min.js"></script>
    <!-- IE10 viewport hack for Surface/desktop Windows 8 bug -->
    <script src="../../assets/js/ie10-viewport-bug-workaround.js"></script>
  </body>
</html>
